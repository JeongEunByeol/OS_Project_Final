package daengdaeng.bingo;

import javax.swing.*;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


// JPanel 상속한 빙고게임판
public class BingoGame extends JPanel {
	// 빙고 버튼배열
    ArrayList<BingoButton> bingoArray = new ArrayList<>();

    ObjectOutputStream writer;	// 송신용 스트림

    String user = "";		// 내 이름
    String vsUser = "";		// 상대이름

    public BingoGame() {
    	// 빙고 판의 외형 설정
        setSize(600, 600);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setBackground(Color.WHITE);
        setLayout(new GridLayout(5,5));

    }

    // 빙고버튼이 눌려졌을 떄
    public int pressNumber(int number) {
        for (BingoButton bingo : bingoArray) {
        	// 빙고 배열에서 눌러진 번호랑 같은 버튼을 찾음
            if (bingo.getNumberOfBingo() == number) {
            	// 누름
                bingo.setClicked(true);
                // 눌려진 버튼의 인덱스를 반환
                return bingoArray.indexOf(bingo);
            }
        }
        return -1;
    }

    // 특정 인덱스의 버튼을 누르는 메소드
    public void setClicked(int index) {
        bingoArray.get(index).setClicked(true);
    }

    // 이겼는지를 확인하는 메소드
    // 빙고가 5개가 나와야함
    public boolean checkWin() {
        int bingoNumber = 0;

        int crossClicked = 0;
        int reverseCrossClicked = 0;

        for (int i=0; i<5; i++) {
            int rowClicked = 0;
            int colClicked = 0;

            for (int j=0; j<5; j++) {
                if (bingoArray.get(i*5 + j).isClicked()) rowClicked++; //가로
                if (bingoArray.get(i + j*5).isClicked()) colClicked++; //세로
            }
            if (rowClicked == 5) bingoNumber++; // 가로 한줄로 5개가 눌러졌을때 빙고 추가
            if (colClicked == 5) bingoNumber++; // 새로 한줄로 5개가 눌러졌을떄 빙고 추가

            // 대각선
            if (bingoArray.get(i*5 + i).isClicked()) crossClicked++;
            if (bingoArray.get((4*(i+1))).isClicked()) reverseCrossClicked++;
        }
        if (crossClicked == 5) bingoNumber++; // \방향 빙고시 빙고 추가
        if (reverseCrossClicked == 5) bingoNumber++;// /방향 빙고시 빙고 추가

        // 빙고가 5개이상이면 승리
        if (bingoNumber >= 5) {
            return true;
        } else {
            return false;
        }
    }

    // 빙고판을 만드는 메소드
    public void makeBoard() {
    	// 배열 초기화
        bingoArray.clear();

        // 1~50까지 숫자를 각각 가진 배열 생성
        for (int i=1; i<=50; i++){
            bingoArray.add(new BingoButton(i));
        }

        // 배열을 섞어줌
        Collections.shuffle(bingoArray);

        // 배열의 26번째부터는 잘라줌
        for (int i=25; i<50; i++) {
            bingoArray.remove(25);
        }

        // 만들어진 25개의 빙고버튼을 레이아웃에 등록
        for (BingoButton bingo : bingoArray) {
            add(bingo);
        }

        // 뷰를 다시 그려줌
        repaint();
        revalidate();
    }

    // 빈 빙고판(상대방용)을 만듬
    public void makeEmptyBoard() {
        bingoArray.clear();

        // 0번 숫자의 빙고버튼을 만들어 채움
        for (int i=1; i<=25; i++){
            bingoArray.add(new BingoButton(0));
        }

        for (BingoButton bingo : bingoArray) {
            add(bingo);
        }

        repaint();
        revalidate();
    }

    // 빙고의 활성화 유무를 결정(내 턴이 아닐때, 상대방용 빙고판은 접근 불가하게 설정)
    public void setBoard(boolean isEnabled) {
        for (BingoButton bingo : bingoArray) {
            bingo.setEnabled(isEnabled);
        }
    }
    
    // JButton을 상속한 빙고버튼
    class BingoButton extends JButton implements ActionListener{
        private int numberOfBingo; // 빙고 버튼의 숫자
        private boolean isClicked; // 눌려졌는지 아닌지

        public BingoButton(int bingoNumber) {
            super();
            setNumberOfBingo(bingoNumber);
            addActionListener(this);
//            setBorderPainted(false);
//            setContentAreaFilled(false);
        }

        // 빙고버튼에 맞는 이미지를 가져와서 반환
        // -1 체크된 빙고버튼
        // 0 빈 빙고버튼(상대방용)
        // 1~50 빙고버튼
        ImageIcon getImage(int bingoNumber) {
            return new ImageIcon(bingoNumber + ".jpg");
        }

        public int getNumberOfBingo() {
            return numberOfBingo;
        }

        // 빙고 버튼에 숫자를 할당하며 알맞는 이미지를 설정
        public void setNumberOfBingo(int numberOfBingo) {
            this.numberOfBingo = numberOfBingo;
//            setText(numberOfBingo + "");
              setIcon(getImage(numberOfBingo));
        }

        public boolean isClicked() {
            return isClicked;
        }

        public void setClicked(boolean clicked) {
            isClicked = clicked;
            setIcon(getImage(-1));
        }

        // 눌렀을 때의 동작 설정
        @Override
        public void actionPerformed(ActionEvent e) {
        	// 이미 누른 버튼이면 경고창 띄움
            if (isClicked) {
                JOptionPane.showMessageDialog(null, "이미 선택되었습니다!");
                return;
            }
            
            // 눌러진 상태 설정
            setClicked(true);
            
            // 상대방에게 내가 누른 빙고버튼의 숫자를 보냄
            try {
                writer.writeObject(new BingoMessage(BingoMessage.MsgType.GAME_DATA, user, vsUser, numberOfBingo + ""));
                writer.writeObject(new BingoMessage(BingoMessage.MsgType.BOARD_DATA, user, vsUser, bingoArray.indexOf(this)+""));

                writer.flush();
                setBoard(false);

                // 이겼을 경우에는 이겼다는 메세지를 상대방에게 보냄
                if (checkWin()) {
                    writer.writeObject(new BingoMessage(BingoMessage.MsgType.GAME_STATUS, user, vsUser, "end"));
                    writer.flush();
                    JOptionPane.showMessageDialog(null, "Win!");
                }
            } catch(Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getVsUser() {
        return vsUser;
    }

    public void setVsUser(String vsUser) {
        this.vsUser = vsUser;
    }
}
