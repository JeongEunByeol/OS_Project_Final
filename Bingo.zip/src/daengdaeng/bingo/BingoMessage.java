package daengdaeng.bingo;

import java.io.Serializable;

public class BingoMessage implements Serializable{
    public enum MsgType {
        NO_ACT,             // Dummy
        LOGIN,              // 로그인 신호
        LOGOUT,             // 로그아웃 신호
        LOGIN_FAIL,         // 로그인 실패 메세지
        LOGIN_LIST,         // 로그인 목록
        CHAT_MESSAGE,       // 채팅 메세지, Content는 메세지
        GAME_STATUS,        // 게임 상태, Content는 Start, Error, End
        GAME_DATA,          // 게임 데이터, Content는 빙고번호
        BOARD_DATA          // 보드 데이터, Content는 빙고칸 번호
    }

    // 사용자 명 중 자신을 제외한 모든 로그인되어 있는
    // 사용자를 나타내는 식별문
    public static final String ALL = "전체";	 

    private MsgType type;	// 메세지 타입
    private String sender;	// 보내는 사람
    private String receiver;// 받는 사람
    private String content;	// 메세지 내용

    public BingoMessage(MsgType type, String sender, String receiver, String content) {
        this.type = type;
        this.sender = sender;
        this.receiver = receiver;
        this.content = content;
    }

    public MsgType getType() {
        return type;
    }

    public void setType(MsgType type) {
        this.type = type;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "BingoMessage{" +
                "type=" + type +
                ", sender='" + sender + '\'' +
                ", receiver='" + receiver + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
